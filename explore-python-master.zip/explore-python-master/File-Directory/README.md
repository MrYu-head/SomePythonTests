# 文件和目录

本章主要介绍文件和目录操作，包含以下部分：

* [读写文本文件](./text_file_io.md)
* [读写二进制文件](./binary_file_io.md)
* [os 模块](./os.md)


