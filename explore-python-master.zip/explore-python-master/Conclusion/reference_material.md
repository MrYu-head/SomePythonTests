# 参考资料

本书的参考资料主要有：

- 《Python 基础教程》
- 《Python 核心编程》
- [廖雪峰 python 教程](https://wizardforcel.gitbooks.io/liaoxuefeng/content/py2/1.html)
- [Python进阶 · GitBook](https://www.gitbook.com/book/eastlakeside/interpy-zh/details)
- [python3-cookbook 2.0.0 文档](http://python3-cookbook.readthedocs.io/zh_CN/latest/index.html)

